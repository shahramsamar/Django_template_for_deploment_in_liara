Those are templates with env or dockerbasefile  for deployment.
